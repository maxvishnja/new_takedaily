<?php
class Cornerstone_Control_Number extends Cornerstone_Control {

}